# Changelog

## [1.0.0] - 2025-12-09

### Added
- Initial release of Tales of Arcana Races module
- 222 complete races from Tales of Arcana Race Guide
- Ability score modifiers for all races
- Movement speeds (walk, fly, swim, climb)
- Languages for each race
- Racial traits and heritage descriptions

### Features
- Full Foundry VTT v12+ compatibility
- D&D 5e system support
- Easy drag-and-drop to character sheets
- Organized compendium structure
